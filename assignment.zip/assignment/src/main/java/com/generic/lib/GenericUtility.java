package com.generic.lib;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class GenericUtility {

	InputStream input;
	Properties prop;

	public String getConfigProperty(String property){
		Properties prop = new Properties();
		try { 	

			input = new FileInputStream("Config.properties"); 
			prop.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop.getProperty(property);
	}

}
