package com.generic.lib;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebUtility {
	WebDriver driver;
	WebDriverWait wait;

	public WebUtility(WebDriver driver){
		this.driver=driver;

	}

	public void fillTextBox(By by, String inputData){
		driver.findElement(by).sendKeys(inputData);
	}


	public void clickElement(By by){
		wait = new WebDriverWait (driver, 15);
		wait.until(ExpectedConditions.elementToBeClickable(by)).click();
		//wait.until(ExpectedConditions.elementToBeClickable(by);
		//driver.findElement(by).click();
	}

	public void waitTillInvisibilityOfElement(By by){
		wait = new WebDriverWait (driver, 15);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
	}

	public void hoverTo(By by){


		wait = new WebDriverWait (driver, 15);
		wait.until(ExpectedConditions.elementToBeClickable(by));
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(by)).build().perform();
	}

	public void switchTab(){
		for (String windowsHandle : driver.getWindowHandles()) {
			driver.switchTo().window(windowsHandle);
		}
		//return driver;
	}



	public void maximizeBrowser(){
		driver.manage().window().maximize();
		//return driver;
	}

	public String SetImplicitWaitInMilliSeconds(int timeOut)
	{
		driver.manage().timeouts().implicitlyWait(timeOut, TimeUnit.MILLISECONDS);
		return "Timeout set to " + timeOut + " milli seconds.";
	}

	public Boolean isVisible(By by)
	{
		SetImplicitWaitInMilliSeconds(500);
		if ((driver.findElements(by).size() != 0) && (driver.findElement(by).isDisplayed()))
		{
			SetImplicitWaitInMilliSeconds(5000);
			return Boolean.valueOf(true);
		}
		SetImplicitWaitInMilliSeconds(5000);
		return Boolean.valueOf(false);
	}


}
