package com.uc.assignment.remotecontrol;

public class RemoteOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TV_Remote tvRemote = new TV_Remote();
		tvRemote.switchOn();
		tvRemote.switchOff();		
		tvRemote.gotoParticularChannel();
		tvRemote.goToNextChannel();
		tvRemote.goToPreviousChannel();
		tvRemote.switchOff();

	}

}
