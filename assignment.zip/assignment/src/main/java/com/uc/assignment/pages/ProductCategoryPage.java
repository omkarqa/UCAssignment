package com.uc.assignment.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;

import com.generic.lib.WebUtility;

public class ProductCategoryPage {

	WebDriver driver;
	WebUtility webUtil;
	int productSize;

	By addToCartLnk = By.xpath("//button[text()='ADD TO CART']");

	public  ProductCategoryPage(WebDriver driver){
		this.driver=driver;
		webUtil = new WebUtility(driver);
	}

	public void chooseSizeOfProduct(int productSize){
		//this.productSize = productSize;
		webUtil.clickElement(By.xpath("//span[text()='Size- UK/India']/..//a[text()='"+productSize+"']"));

	}

	public void addProductToCart(){
		webUtil.clickElement(addToCartLnk);
		webUtil.waitTillInvisibilityOfElement(addToCartLnk);
	}




}
