package com.uc.assignment.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.generic.lib.WebUtility;

public class MyCartPage {

	WebDriver driver;
	WebUtility webUtil;
	int productSize;

	By placeOrderLnk = By.xpath("//span[text()='Place Order']");

	public  MyCartPage(WebDriver driver){
		this.driver=driver;
		webUtil = new WebUtility(driver);
	}

	public boolean isPlaceOrderVisible(){
		return webUtil.isVisible(placeOrderLnk);
	}

	public boolean isProductVisibleOnCartPage(String product){
		return webUtil.isVisible(By.xpath("//a[contains(text(),'"+product+"')]"));

	}

}
