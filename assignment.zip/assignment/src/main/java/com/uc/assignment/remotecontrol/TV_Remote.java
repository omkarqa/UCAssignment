package com.uc.assignment.remotecontrol;

import java.util.List;

public class TV_Remote implements Remote_Control {

	List<String> favorateChannels;
	List<String> allChannels;


	@Override
	public void switchOn() {
		System.out.println("switching on the TV");
	}

	@Override
	public void switchOff() {
		System.out.println("switching off the TV");

	}

	public void increaseVolume(){
		System.out.println("increasing the volume of TV");
	}

	public void decreaseVolume(){
		System.out.println("decreasing the volume of TV");
	}

	public void gotoParticularChannel(){
		System.out.println("Going to particular channel of TV");
	}

	public void goToNextChannel(){
		System.out.println("Going to particular next channel of TV");
	}

	public void goToPreviousChannel(){
		System.out.println("Going to previous channel of TV");
	}

	public List<String> getFavourateChannelList(){
		return favorateChannels;
	}

	public List<String> getAllChannelList(){
		return allChannels;
	}






}
