package com.uc.assignment.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import com.generic.lib.WebUtility;

public class MenuList {

	WebDriver driver;
	WebUtility webUtil;

	private	By mainMenuListItemMen =By.xpath("//span[text()='Men']");

	public MenuList(WebDriver driver){
		this.driver=driver;
		webUtil = new WebUtility(driver);
	}

	public void hoverToMainMenuListItemMen(){
		webUtil.hoverTo(mainMenuListItemMen);

	}

	public void chooseSubCategoryFromMenu(String mainMenuCategory, String subMenuCategory){
		webUtil.clickElement(By.xpath("//li[span[contains(text(), '"+mainMenuCategory+"')]]//a[text()='"+subMenuCategory+"']"));
		webUtil.waitTillInvisibilityOfElement(By.xpath("//h2[text()='Deals of the Day']"));

	}








}
