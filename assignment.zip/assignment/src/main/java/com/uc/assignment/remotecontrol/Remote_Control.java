package com.uc.assignment.remotecontrol;

public interface Remote_Control {
	
	abstract public void switchOn();
	abstract public void switchOff();
	

}
